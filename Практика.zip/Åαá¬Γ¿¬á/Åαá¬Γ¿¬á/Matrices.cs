﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Практика_
{
    internal class Matrices
    {
        private double a_11;
        private double a_12;
        private double a_13;
        private double a_21;
        private double a_22;
        private double a_23;
        private double a_31;
        private double a_32;
        private double a_33;

        public double b_11 { get { return a_11; } }
        public double b_12 { get { return a_12; } }
        public double b_13 { get { return a_13; } }
        public double b_21 { get { return a_21; } }
        public double b_22 { get { return a_22; } }
        public double b_23 { get { return a_23; } }
        public double b_31 { get { return a_31; } }
        public double b_32 { get { return a_32; } }
        public double b_33 { get { return a_33; } }

        public Matrices(double b_11, double b_12, double b_13, double b_21, double b_22,
            double b_23, double b_31, double b_32, double b_33)
        {
            a_11 = b_11;
            a_12 = b_12;
            a_13 = b_13;
            a_21 = b_21;
            a_22 = b_22;
            a_23 = b_23;
            a_31 = b_31;
            a_32 = b_32;
            a_33 = b_33;
        }

        public static Matrices operator *(double c, Matrices A)
        {
            double b_11 = c * A.a_11;
            double b_12 = c * A.a_12;
            double b_13 = c * A.a_13;
            double b_21 = c * A.a_21;
            double b_22 = c * A.a_22;
            double b_23 = c * A.a_23;
            double b_31 = c * A.a_31;
            double b_32 = c * A.a_32;
            double b_33 = c * A.a_33;
            return new Matrices(b_11, b_12, b_13, b_21, b_22, b_23, b_31, b_32, b_33);
        }

        public static Matrices operator *(Matrices A, double c)
        {
            double b_11 = A.a_11 * c;
            double b_12 = A.a_12 * c;
            double b_13 = A.a_13 * c;
            double b_21 = A.a_21 * c;
            double b_22 = A.a_22 * c;
            double b_23 = A.a_23 * c;
            double b_31 = A.a_31 * c;
            double b_32 = A.a_32 * c;
            double b_33 = A.a_33 * c;
            return new Matrices(b_11, b_12, b_13, b_21, b_22, b_23, b_31, b_32, b_33);
        }

        public static Matrices operator +(Matrices A, Matrices B)
        {
            double c_11 = A.a_11 + B.a_11;
            double c_12 = A.a_12 + B.a_12;
            double c_13 = A.a_13 + B.a_13;
            double c_21 = A.a_21 + B.a_21;
            double c_22 = A.a_22 + B.a_22;
            double c_23 = A.a_23 + B.a_23;
            double c_31 = A.a_31 + B.a_31;
            double c_32 = A.a_32 + B.a_32;
            double c_33 = A.a_33 + B.a_33;
            return new Matrices(c_11, c_12, c_13, c_21, c_22, c_22, c_23, c_32, c_33);
        }

        public static Matrices operator *(Matrices A, Matrices B)
        {
            double c_11 = A.a_11 * B.a_11 + A.a_12 * B.a_21 + A.a_13 * B.a_31;
            double c_12 = A.a_11 * B.a_12 + A.a_12 * B.a_22 + A.a_13 * B.a_32;
            double c_13 = A.a_11 * B.a_13 + A.a_12 * B.a_23 + A.a_13 * B.a_33;
            double c_21 = A.a_21 * B.a_11 + A.a_22 * B.a_21 + A.a_23 * B.a_31;
            double c_22 = A.a_21 * B.a_12 + A.a_22 * B.a_22 + A.a_23 * B.a_32;
            double c_23 = A.a_21 * B.a_13 + A.a_22 * B.a_23 + A.a_23 * B.a_33;
            double c_31 = A.a_31 * B.a_11 + A.a_32 * B.a_21 + A.a_33 * B.a_31;
            double c_32 = A.a_31 * B.a_12 + A.a_32 * B.a_22 + A.a_33 * B.a_32;
            double c_33 = A.a_31 * B.a_13 + A.a_32 * B.a_23 + A.a_33 * B.a_33;
            return new Matrices(c_11, c_12, c_13, c_21, c_22, c_23, c_31, c_32, c_33);
        }

        public static double Det(Matrices A)
        {
            double c_1 = A.a_22 * A.a_33 - A.a_23 * A.a_32;
            double c_2 = A.a_21 * A.a_33 - A.a_23 * A.a_31;
            double c_3 = A.a_21 * A.a_32 - A.a_22 * A.a_31;
            double det = A.a_11 * c_1 - A.a_12 * c_2 + A.a_13 * c_3;
            return det;
        }

    }
}
