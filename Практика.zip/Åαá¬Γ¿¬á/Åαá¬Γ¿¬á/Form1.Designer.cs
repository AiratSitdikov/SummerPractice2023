﻿namespace Практика_
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            textBoxA11 = new TextBox();
            textBoxA22 = new TextBox();
            textBoxA21 = new TextBox();
            textBoxA12 = new TextBox();
            textBoxA31 = new TextBox();
            textBoxA32 = new TextBox();
            textBoxA13 = new TextBox();
            textBoxA23 = new TextBox();
            textBoxA33 = new TextBox();
            label2 = new Label();
            textBoxB11 = new TextBox();
            textBoxB12 = new TextBox();
            textBoxB13 = new TextBox();
            textBoxB21 = new TextBox();
            textBoxB22 = new TextBox();
            textBoxB23 = new TextBox();
            textBoxB31 = new TextBox();
            textBoxB32 = new TextBox();
            textBoxB33 = new TextBox();
            label3 = new Label();
            textBoxC11 = new TextBox();
            textBoxC12 = new TextBox();
            textBoxC13 = new TextBox();
            textBoxC21 = new TextBox();
            textBoxC22 = new TextBox();
            textBoxC23 = new TextBox();
            textBoxC31 = new TextBox();
            textBoxC32 = new TextBox();
            textBoxC33 = new TextBox();
            label4 = new Label();
            panel1 = new Panel();
            label5 = new Label();
            dataGridView1 = new DataGridView();
            Column1 = new DataGridViewTextBoxColumn();
            Column2 = new DataGridViewTextBoxColumn();
            Column3 = new DataGridViewTextBoxColumn();
            button1 = new Button();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Gold;
            label1.Location = new Point(25, 66);
            label1.Name = "label1";
            label1.Size = new Size(33, 20);
            label1.TabIndex = 0;
            label1.Text = "A =";
            // 
            // textBoxA11
            // 
            textBoxA11.BackColor = Color.Aqua;
            textBoxA11.BorderStyle = BorderStyle.FixedSingle;
            textBoxA11.Location = new Point(76, 30);
            textBoxA11.Name = "textBoxA11";
            textBoxA11.Size = new Size(43, 27);
            textBoxA11.TabIndex = 1;
            textBoxA11.KeyPress += textBoxA11_KeyPress;
            // 
            // textBoxA22
            // 
            textBoxA22.BackColor = Color.Aqua;
            textBoxA22.BorderStyle = BorderStyle.FixedSingle;
            textBoxA22.Location = new Point(125, 63);
            textBoxA22.Name = "textBoxA22";
            textBoxA22.Size = new Size(43, 27);
            textBoxA22.TabIndex = 2;
            textBoxA22.KeyPress += textBoxA22_KeyPress;
            // 
            // textBoxA21
            // 
            textBoxA21.BackColor = Color.Aqua;
            textBoxA21.BorderStyle = BorderStyle.FixedSingle;
            textBoxA21.Location = new Point(76, 63);
            textBoxA21.Name = "textBoxA21";
            textBoxA21.Size = new Size(43, 27);
            textBoxA21.TabIndex = 3;
            textBoxA21.TextChanged += textBoxA11_TextChanged;
            textBoxA21.KeyPress += textBoxA21_KeyPress;
            // 
            // textBoxA12
            // 
            textBoxA12.BackColor = Color.Aqua;
            textBoxA12.BorderStyle = BorderStyle.FixedSingle;
            textBoxA12.Location = new Point(125, 30);
            textBoxA12.Name = "textBoxA12";
            textBoxA12.Size = new Size(43, 27);
            textBoxA12.TabIndex = 4;
            textBoxA12.KeyPress += textBoxA12_KeyPress;
            // 
            // textBoxA31
            // 
            textBoxA31.BackColor = Color.Aqua;
            textBoxA31.BorderStyle = BorderStyle.FixedSingle;
            textBoxA31.Location = new Point(76, 96);
            textBoxA31.Name = "textBoxA31";
            textBoxA31.Size = new Size(43, 27);
            textBoxA31.TabIndex = 5;
            textBoxA31.KeyPress += textBoxA31_KeyPress;
            // 
            // textBoxA32
            // 
            textBoxA32.BackColor = Color.Aqua;
            textBoxA32.BorderStyle = BorderStyle.FixedSingle;
            textBoxA32.Location = new Point(125, 96);
            textBoxA32.Name = "textBoxA32";
            textBoxA32.Size = new Size(43, 27);
            textBoxA32.TabIndex = 6;
            textBoxA32.KeyPress += textBoxA32_KeyPress;
            // 
            // textBoxA13
            // 
            textBoxA13.BackColor = Color.Aqua;
            textBoxA13.BorderStyle = BorderStyle.FixedSingle;
            textBoxA13.Location = new Point(174, 30);
            textBoxA13.Name = "textBoxA13";
            textBoxA13.Size = new Size(43, 27);
            textBoxA13.TabIndex = 7;
            textBoxA13.KeyPress += textBoxA13_KeyPress;
            // 
            // textBoxA23
            // 
            textBoxA23.BackColor = Color.Aqua;
            textBoxA23.BorderStyle = BorderStyle.FixedSingle;
            textBoxA23.Location = new Point(174, 63);
            textBoxA23.Name = "textBoxA23";
            textBoxA23.Size = new Size(43, 27);
            textBoxA23.TabIndex = 8;
            textBoxA23.KeyPress += textBoxA23_KeyPress;
            // 
            // textBoxA33
            // 
            textBoxA33.BackColor = Color.Aqua;
            textBoxA33.BorderStyle = BorderStyle.FixedSingle;
            textBoxA33.Location = new Point(174, 96);
            textBoxA33.Name = "textBoxA33";
            textBoxA33.Size = new Size(43, 27);
            textBoxA33.TabIndex = 9;
            textBoxA33.KeyPress += textBoxA33_KeyPress;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.Gold;
            label2.Location = new Point(290, 66);
            label2.Name = "label2";
            label2.Size = new Size(32, 20);
            label2.TabIndex = 10;
            label2.Text = "B =";
            // 
            // textBoxB11
            // 
            textBoxB11.BackColor = Color.Aqua;
            textBoxB11.BorderStyle = BorderStyle.FixedSingle;
            textBoxB11.Location = new Point(336, 30);
            textBoxB11.Name = "textBoxB11";
            textBoxB11.Size = new Size(43, 27);
            textBoxB11.TabIndex = 11;
            textBoxB11.KeyPress += textBoxB11_KeyPress;
            // 
            // textBoxB12
            // 
            textBoxB12.BackColor = Color.Aqua;
            textBoxB12.BorderStyle = BorderStyle.FixedSingle;
            textBoxB12.Location = new Point(385, 30);
            textBoxB12.Name = "textBoxB12";
            textBoxB12.Size = new Size(43, 27);
            textBoxB12.TabIndex = 12;
            textBoxB12.KeyPress += textBoxB12_KeyPress;
            // 
            // textBoxB13
            // 
            textBoxB13.BackColor = Color.Aqua;
            textBoxB13.BorderStyle = BorderStyle.FixedSingle;
            textBoxB13.Location = new Point(434, 30);
            textBoxB13.Name = "textBoxB13";
            textBoxB13.Size = new Size(43, 27);
            textBoxB13.TabIndex = 13;
            textBoxB13.KeyPress += textBoxB13_KeyPress;
            // 
            // textBoxB21
            // 
            textBoxB21.BackColor = Color.Aqua;
            textBoxB21.BorderStyle = BorderStyle.FixedSingle;
            textBoxB21.Location = new Point(336, 63);
            textBoxB21.Name = "textBoxB21";
            textBoxB21.Size = new Size(43, 27);
            textBoxB21.TabIndex = 14;
            textBoxB21.KeyPress += textBoxB21_KeyPress;
            // 
            // textBoxB22
            // 
            textBoxB22.BackColor = Color.Aqua;
            textBoxB22.BorderStyle = BorderStyle.FixedSingle;
            textBoxB22.Location = new Point(385, 63);
            textBoxB22.Name = "textBoxB22";
            textBoxB22.Size = new Size(43, 27);
            textBoxB22.TabIndex = 15;
            textBoxB22.KeyPress += textBoxB22_KeyPress;
            // 
            // textBoxB23
            // 
            textBoxB23.BackColor = Color.Aqua;
            textBoxB23.BorderStyle = BorderStyle.FixedSingle;
            textBoxB23.Location = new Point(434, 63);
            textBoxB23.Name = "textBoxB23";
            textBoxB23.Size = new Size(43, 27);
            textBoxB23.TabIndex = 16;
            textBoxB23.KeyPress += textBoxB23_KeyPress;
            // 
            // textBoxB31
            // 
            textBoxB31.BackColor = Color.Aqua;
            textBoxB31.BorderStyle = BorderStyle.FixedSingle;
            textBoxB31.Location = new Point(336, 96);
            textBoxB31.Name = "textBoxB31";
            textBoxB31.Size = new Size(43, 27);
            textBoxB31.TabIndex = 17;
            textBoxB31.KeyPress += textBoxB31_KeyPress;
            // 
            // textBoxB32
            // 
            textBoxB32.BackColor = Color.Aqua;
            textBoxB32.BorderStyle = BorderStyle.FixedSingle;
            textBoxB32.Location = new Point(385, 96);
            textBoxB32.Name = "textBoxB32";
            textBoxB32.Size = new Size(43, 27);
            textBoxB32.TabIndex = 18;
            textBoxB32.KeyPress += textBoxB32_KeyPress;
            // 
            // textBoxB33
            // 
            textBoxB33.BackColor = Color.Aqua;
            textBoxB33.BorderStyle = BorderStyle.FixedSingle;
            textBoxB33.Location = new Point(434, 98);
            textBoxB33.Name = "textBoxB33";
            textBoxB33.Size = new Size(43, 27);
            textBoxB33.TabIndex = 19;
            textBoxB33.KeyPress += textBox33_KeyPress;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = Color.Gold;
            label3.Location = new Point(561, 66);
            label3.Name = "label3";
            label3.Size = new Size(32, 20);
            label3.TabIndex = 20;
            label3.Text = "C =";
            // 
            // textBoxC11
            // 
            textBoxC11.BackColor = Color.Aqua;
            textBoxC11.BorderStyle = BorderStyle.FixedSingle;
            textBoxC11.Location = new Point(607, 30);
            textBoxC11.Name = "textBoxC11";
            textBoxC11.Size = new Size(43, 27);
            textBoxC11.TabIndex = 21;
            textBoxC11.KeyPress += textBoxC11_KeyPress;
            // 
            // textBoxC12
            // 
            textBoxC12.BackColor = Color.Aqua;
            textBoxC12.BorderStyle = BorderStyle.FixedSingle;
            textBoxC12.Location = new Point(656, 30);
            textBoxC12.Name = "textBoxC12";
            textBoxC12.Size = new Size(43, 27);
            textBoxC12.TabIndex = 22;
            textBoxC12.KeyPress += textBoxC12_KeyPress;
            // 
            // textBoxC13
            // 
            textBoxC13.BackColor = Color.Aqua;
            textBoxC13.BorderStyle = BorderStyle.FixedSingle;
            textBoxC13.Location = new Point(705, 30);
            textBoxC13.Name = "textBoxC13";
            textBoxC13.Size = new Size(43, 27);
            textBoxC13.TabIndex = 23;
            textBoxC13.KeyPress += textBoxC13_KeyPress;
            // 
            // textBoxC21
            // 
            textBoxC21.BackColor = Color.Aqua;
            textBoxC21.BorderStyle = BorderStyle.FixedSingle;
            textBoxC21.Location = new Point(607, 63);
            textBoxC21.Name = "textBoxC21";
            textBoxC21.Size = new Size(43, 27);
            textBoxC21.TabIndex = 24;
            textBoxC21.KeyPress += textBoxC21_KeyPress;
            // 
            // textBoxC22
            // 
            textBoxC22.BackColor = Color.Aqua;
            textBoxC22.BorderStyle = BorderStyle.FixedSingle;
            textBoxC22.Location = new Point(656, 63);
            textBoxC22.Name = "textBoxC22";
            textBoxC22.Size = new Size(43, 27);
            textBoxC22.TabIndex = 25;
            textBoxC22.KeyPress += textBoxC22_KeyPress;
            // 
            // textBoxC23
            // 
            textBoxC23.BackColor = Color.Aqua;
            textBoxC23.BorderStyle = BorderStyle.FixedSingle;
            textBoxC23.Location = new Point(705, 63);
            textBoxC23.Name = "textBoxC23";
            textBoxC23.Size = new Size(43, 27);
            textBoxC23.TabIndex = 26;
            textBoxC23.KeyPress += textBoxC23_KeyPress;
            // 
            // textBoxC31
            // 
            textBoxC31.BackColor = Color.Aqua;
            textBoxC31.BorderStyle = BorderStyle.FixedSingle;
            textBoxC31.Location = new Point(607, 96);
            textBoxC31.Name = "textBoxC31";
            textBoxC31.Size = new Size(43, 27);
            textBoxC31.TabIndex = 27;
            textBoxC31.KeyPress += textBoxC31_KeyPress;
            // 
            // textBoxC32
            // 
            textBoxC32.BackColor = Color.Aqua;
            textBoxC32.BorderStyle = BorderStyle.FixedSingle;
            textBoxC32.Location = new Point(656, 96);
            textBoxC32.Name = "textBoxC32";
            textBoxC32.Size = new Size(43, 27);
            textBoxC32.TabIndex = 28;
            textBoxC32.KeyPress += textBoxC32_KeyPress;
            // 
            // textBoxC33
            // 
            textBoxC33.BackColor = Color.Aqua;
            textBoxC33.BorderStyle = BorderStyle.FixedSingle;
            textBoxC33.ForeColor = SystemColors.WindowText;
            textBoxC33.Location = new Point(705, 96);
            textBoxC33.Name = "textBoxC33";
            textBoxC33.Size = new Size(43, 27);
            textBoxC33.TabIndex = 29;
            textBoxC33.KeyPress += textBoxC33_KeyPress;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.BackColor = Color.PaleTurquoise;
            label4.Location = new Point(54, 279);
            label4.Name = "label4";
            label4.Size = new Size(137, 20);
            label4.TabIndex = 30;
            label4.Text = "D = (|AB|/|BC|)*A =";
            // 
            // panel1
            // 
            panel1.BackColor = Color.YellowGreen;
            panel1.Controls.Add(label5);
            panel1.Controls.Add(dataGridView1);
            panel1.Controls.Add(label4);
            panel1.Controls.Add(textBoxC33);
            panel1.Controls.Add(textBoxC32);
            panel1.Controls.Add(textBoxC31);
            panel1.Controls.Add(textBoxC23);
            panel1.Controls.Add(textBoxC22);
            panel1.Controls.Add(textBoxC21);
            panel1.Controls.Add(textBoxC13);
            panel1.Controls.Add(textBoxC12);
            panel1.Controls.Add(textBoxC11);
            panel1.Controls.Add(label3);
            panel1.Controls.Add(textBoxB33);
            panel1.Controls.Add(textBoxB32);
            panel1.Controls.Add(textBoxB31);
            panel1.Controls.Add(textBoxB23);
            panel1.Controls.Add(textBoxB22);
            panel1.Controls.Add(textBoxB21);
            panel1.Controls.Add(textBoxB13);
            panel1.Controls.Add(textBoxB12);
            panel1.Controls.Add(textBoxB11);
            panel1.Controls.Add(label2);
            panel1.Controls.Add(textBoxA33);
            panel1.Controls.Add(textBoxA23);
            panel1.Controls.Add(textBoxA13);
            panel1.Controls.Add(textBoxA32);
            panel1.Controls.Add(textBoxA31);
            panel1.Controls.Add(textBoxA12);
            panel1.Controls.Add(textBoxA21);
            panel1.Controls.Add(textBoxA22);
            panel1.Controls.Add(textBoxA11);
            panel1.Controls.Add(label1);
            panel1.ForeColor = SystemColors.ControlText;
            panel1.Location = new Point(36, 12);
            panel1.Name = "panel1";
            panel1.Size = new Size(806, 448);
            panel1.TabIndex = 31;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.BackColor = Color.Yellow;
            label5.Location = new Point(378, 405);
            label5.Name = "label5";
            label5.Size = new Size(0, 20);
            label5.TabIndex = 32;
            // 
            // dataGridView1
            // 
            dataGridView1.AllowUserToAddRows = false;
            dataGridView1.AllowUserToDeleteRows = false;
            dataGridView1.AllowUserToResizeColumns = false;
            dataGridView1.AllowUserToResizeRows = false;
            dataGridView1.BackgroundColor = Color.LimeGreen;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.ColumnHeadersVisible = false;
            dataGridView1.Columns.AddRange(new DataGridViewColumn[] { Column1, Column2, Column3 });
            dataGridView1.Location = new Point(197, 239);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.ReadOnly = true;
            dataGridView1.RowHeadersVisible = false;
            dataGridView1.RowHeadersWidth = 51;
            dataGridView1.RowTemplate.Height = 32;
            dataGridView1.Size = new Size(428, 96);
            dataGridView1.TabIndex = 31;
            // 
            // Column1
            // 
            Column1.HeaderText = "";
            Column1.MinimumWidth = 6;
            Column1.Name = "Column1";
            Column1.ReadOnly = true;
            Column1.Width = 125;
            // 
            // Column2
            // 
            Column2.HeaderText = "";
            Column2.MinimumWidth = 6;
            Column2.Name = "Column2";
            Column2.ReadOnly = true;
            Column2.Width = 125;
            // 
            // Column3
            // 
            Column3.HeaderText = "";
            Column3.MinimumWidth = 6;
            Column3.Name = "Column3";
            Column3.ReadOnly = true;
            Column3.Width = 125;
            // 
            // button1
            // 
            button1.Location = new Point(398, 469);
            button1.Name = "button1";
            button1.Size = new Size(94, 29);
            button1.TabIndex = 32;
            button1.Text = "Вычислить";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Salmon;
            ClientSize = new Size(876, 510);
            Controls.Add(button1);
            Controls.Add(panel1);
            MaximumSize = new Size(894, 557);
            MinimumSize = new Size(894, 557);
            Name = "Form1";
            Text = "Form1";
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Label label1;
        private TextBox textBoxA11;
        private TextBox textBoxA22;
        private TextBox textBoxA21;
        private TextBox textBoxA12;
        private TextBox textBoxA31;
        private TextBox textBoxA32;
        private TextBox textBoxA13;
        private TextBox textBoxA23;
        private TextBox textBoxA33;
        private Label label2;
        private TextBox textBoxB11;
        private TextBox textBoxB12;
        private TextBox textBoxB13;
        private TextBox textBoxB21;
        private TextBox textBoxB22;
        private TextBox textBoxB23;
        private TextBox textBoxB31;
        private TextBox textBoxB32;
        private TextBox textBoxB33;
        private Label label3;
        private TextBox textBoxC11;
        private TextBox textBoxC12;
        private TextBox textBoxC13;
        private TextBox textBoxC21;
        private TextBox textBoxC22;
        private TextBox textBoxC23;
        private TextBox textBoxC31;
        private TextBox textBoxC32;
        private TextBox textBoxC33;
        private Label label4;
        private Panel panel1;
        private DataGridView dataGridView1;
        private Button button1;
        private Label label5;
        private DataGridViewTextBoxColumn Column1;
        private DataGridViewTextBoxColumn Column2;
        private DataGridViewTextBoxColumn Column3;
    }
}